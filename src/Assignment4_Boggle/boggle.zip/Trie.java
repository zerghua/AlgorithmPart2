import java.util.HashMap;

/**
 * Created by HuaZ on 1/30/2018.
 */
public class Trie {
    class TrieNode{
        HashMap<Character, TrieNode> children;
        boolean isEnd;
        TrieNode(){
            children = new HashMap<Character, TrieNode>();
            isEnd = false;
        }
    }

    TrieNode root;
    public Trie() {
        root = new TrieNode();
    }

    /** Inserts a word into the trie. */
    public void insert(String word) {
        TrieNode node = root;
        for(char c : word.toCharArray()){
            if(!node.children.containsKey(c))node.children.put(c, new TrieNode());
            node = node.children.get(c);
        }
        node.isEnd = true;
    }

    /** Returns if the word is in the trie. */
    public boolean contains(String word) {
        TrieNode node = dfs(word);
        return node != null && node.isEnd;
    }

    /** Returns if there is any word in the trie that starts with the given prefix. */
    public boolean startsWith(String prefix) {
        return dfs(prefix) != null;
    }

    public TrieNode dfs(String s){
        TrieNode node = root;
        for(char c : s.toCharArray()){
            if(node.children.containsKey(c)) node = node.children.get(c);
            else return null;
        }
        return node;
    }
}
